# BrumQuest

Installable static PWA for Birmingham city-centre and canal photo quests.

## Local run

A service worker requires HTTP(S), not `file://`.

```bash
python3 -m http.server 8080
```

Open `http://localhost:8080`.

## Core behaviour
- 12 Birmingham photo quests
- GPS proximity validation
- Camera/photo upload
- Image compression + local IndexedDB storage
- Local score/progress persistence
- Ranks and achievements
- Offline application shell
- GitHub Pages-safe relative URLs

## Privacy
Version 1 stores progress and compressed photos only in the browser on the device. No backend or account is used.

## Deployment
This folder can be deployed as-is to GitHub Pages, Cloudflare Pages, Netlify, Vercel static hosting, or any HTTPS static host.
