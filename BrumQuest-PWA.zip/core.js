export function distanceMetres(lat1, lon1, lat2, lon2) {
  const R = 6371000;
  const toRad = d => d * Math.PI / 180;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}

export function scoreFor(completedIds, quests) {
  const set = new Set(completedIds);
  return quests.reduce((sum, q) => sum + (set.has(q.id) ? q.points : 0), 0);
}

export function rankFor(score) {
  if (score >= 1300) return { name: 'Canal Legend', short: 'L', next: null, floor: 1300 };
  if (score >= 850) return { name: 'Towpath Pro', short: 'T', next: 1300, floor: 850 };
  if (score >= 350) return { name: 'Brummie Explorer', short: 'B', next: 850, floor: 350 };
  return { name: 'Canal Rookie', short: 'R', next: 350, floor: 0 };
}

export function badgesFor(completedIds, quests) {
  const set = new Set(completedIds);
  const done = quests.filter(q => set.has(q.id));
  return [
    { id:'first', title:'First Capture', desc:'Complete your first quest.', unlocked: done.length >= 1 },
    { id:'five', title:'Five Alive', desc:'Complete five quests.', unlocked: done.length >= 5 },
    { id:'canals', title:'Canal Collector', desc:'Complete four canal quests.', unlocked: done.filter(q=>q.category==='canal').length >= 4 },
    { id:'landmarks', title:'Brum Spotter', desc:'Complete three landmark quests.', unlocked: done.filter(q=>q.category==='landmark').length >= 3 },
    { id:'creative', title:'Different Angle', desc:'Complete three creative quests.', unlocked: done.filter(q=>q.category==='creative').length >= 3 },
    { id:'all', title:'City Conquered', desc:'Complete every current quest.', unlocked: done.length === quests.length && quests.length > 0 }
  ];
}
