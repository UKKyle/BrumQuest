import { distanceMetres, scoreFor, rankFor, badgesFor } from './core.js';

const quests = [
  {id:'gas-street', title:'Heart of the canals', place:'Gas Street Basin', category:'canal', points:150, lat:52.47507, lon:-1.90798, radius:180, icon:'≈', prompt:'Photograph the canal basin where historic brickwork and modern Birmingham meet.', hint:'Look for water, boats, bridges or the basin architecture in your frame.'},
  {id:'black-sabbath', title:'Heavy metal crossing', place:'Black Sabbath Bridge', category:'landmark', points:150, lat:52.477704, lon:-1.910686, radius:110, icon:'♬', prompt:'Capture the Black Sabbath Bridge or its canal-side tribute.', hint:'The bridge sits above the Broad Street Tunnel.'},
  {id:'old-turn', title:'Three-way water', place:'Old Turn Junction', category:'canal', points:175, lat:52.47924, lon:-1.91385, radius:150, icon:'↗', prompt:'Photograph the open water at Old Turn Junction.', hint:'Try to include a bridge, boat or the island at the junction.'},
  {id:'cambrian', title:'Wharf watcher', place:'Cambrian Wharf', category:'canal', points:125, lat:52.48067, lon:-1.91179, radius:150, icon:'⚓', prompt:'Capture canal life around Cambrian Wharf.', hint:'Moorings, water, lock features and old canal details all count.'},
  {id:'farmers-locks', title:'Lock hunter', place:"Farmer's Bridge Locks", category:'canal', points:200, lat:52.4829, lon:-1.9064, radius:300, icon:'▤', prompt:"Photograph one of the Farmer's Bridge locks.", hint:'Stay on the towpath. Any clearly visible lock chamber or gate counts.'},
  {id:'brindley', title:'Brindley reflections', place:'Brindleyplace', category:'creative', points:100, lat:52.4775, lon:-1.91339, radius:220, icon:'◇', prompt:'Take a reflection photo using the canal or waterside glass around Brindleyplace.', hint:'Make the reflection the main feature of the shot.'},
  {id:'mailbox', title:'Canal meets city', place:'The Mailbox', category:'landmark', points:100, lat:52.47523, lon:-1.90614, radius:170, icon:'▰', prompt:'Photograph The Mailbox from the canal side.', hint:'Include some water or towpath context if you can.'},
  {id:'worcester-bar', title:'The historic divide', place:'Worcester Bar', category:'landmark', points:175, lat:52.47722, lon:-1.91000, radius:160, icon:'═', prompt:'Find and photograph Worcester Bar or the junction around it.', hint:'This is close to where the Worcester & Birmingham Canal meets the BCN.'},
  {id:'narrowboat', title:'Narrowboat colours', place:'City-centre canal zone', category:'creative', points:75, lat:52.4778, lon:-1.9100, radius:900, icon:'▱', prompt:'Photograph a colourful narrowboat somewhere in the city-centre canal zone.', hint:'Do not photograph through windows or intrude on private boat space.'},
  {id:'bridge-frame', title:'Frame a bridge', place:'City-centre canal zone', category:'creative', points:75, lat:52.4785, lon:-1.9100, radius:1000, icon:'⌒', prompt:'Use a canal bridge as a natural frame for your photograph.', hint:'Shoot from a public towpath and keep clear of cyclists and boat operations.'},
  {id:'canal-wildlife', title:'Wild Birmingham', place:'City-centre canal zone', category:'creative', points:100, lat:52.4800, lon:-1.9080, radius:1300, icon:'✦', prompt:'Capture canal wildlife without approaching or feeding it.', hint:'Ducks, geese and other wildlife count. Keep your distance.'},
  {id:'industrial-detail', title:'Industrial fingerprints', place:'Canal quarter', category:'landmark', points:125, lat:52.4810, lon:-1.9090, radius:1300, icon:'⚙', prompt:'Photograph an old canal-side industrial detail: ironwork, brickwork, a lock mechanism or rope marks.', hint:'The detail should be accessible from a normal public route.'}
];

const state = { currentLocation:null, filter:'all', activeQuest:null, pendingPhoto:null, deferredInstall:null };
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];

function getProgress(){
  try { return JSON.parse(localStorage.getItem('brumquest-progress')) || {completed:[]}; }
  catch { return {completed:[]}; }
}
function setProgress(p){ localStorage.setItem('brumquest-progress', JSON.stringify(p)); }
function completedIds(){ return getProgress().completed.map(x=>x.id); }
function isDone(id){ return completedIds().includes(id); }
function score(){ return scoreFor(completedIds(), quests); }

function formatDistance(m){ if(m == null) return ''; return m < 1000 ? `${Math.round(m)} m` : `${(m/1000).toFixed(1)} km`; }
function qDistance(q){ return state.currentLocation ? distanceMetres(state.currentLocation.lat,state.currentLocation.lon,q.lat,q.lon) : null; }
function escapeHtml(s=''){ return s.replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c])); }

function questCard(q){
  const done = isDone(q.id), dist = qDistance(q);
  return `<button class="quest-card ${done?'done':''}" data-quest="${q.id}">
    <span class="quest-icon">${q.icon}</span><span class="quest-copy"><span class="quest-meta">${escapeHtml(q.category)} · ${q.points} pts${dist!=null?` · ${formatDistance(dist)}`:''}</span><strong>${escapeHtml(q.title)}</strong><small>${escapeHtml(q.place)}</small></span><span class="quest-state">${done?'✓':'›'}</span>
  </button>`;
}

function render(){
  const ids=completedIds(), total=score(), rank=rankFor(total), badges=badgesFor(ids,quests), done=getProgress().completed;
  $('#score').textContent=total; $('#completedStat').textContent=ids.length; $('#pointsStat').textContent=total; $('#levelStat').textContent=rank.name.replace('Canal ','');
  $('#profileScore').textContent=total; $('#profileDone').textContent=ids.length; $('#profileBadges').textContent=badges.filter(b=>b.unlocked).length; $('#profileTitle').textContent=rank.name; $('#rankBadge').textContent=rank.short;
  $('#rankProgress').textContent=rank.next ? `${rank.next-total} points until your next rank.` : 'Top rank reached.';
  const sorted=[...quests].sort((a,b)=>{const da=qDistance(a),db=qDistance(b); return da==null?0:da-db});
  $('#nearbyList').innerHTML=sorted.filter(q=>!isDone(q.id)).slice(0,3).map(questCard).join('') || '<div class="empty">Every current quest is complete.</div>';
  $('#questList').innerHTML=sorted.filter(q=>state.filter==='all'||q.category===state.filter).map(questCard).join('');
  $('#badgeGrid').innerHTML=badges.map(b=>`<article class="badge ${b.unlocked?'unlocked':''}"><span>${b.unlocked?'★':'☆'}</span><strong>${escapeHtml(b.title)}</strong><small>${escapeHtml(b.desc)}</small></article>`).join('');
  $('#collectionGrid').innerHTML=done.length ? done.slice().reverse().map(x=>`<article class="capture"><div class="capture-img" data-photo="${x.id}"><span>Loading photo…</span></div><div><span class="quest-meta">${new Date(x.completedAt).toLocaleDateString('en-GB')}</span><strong>${escapeHtml(x.title)}</strong><small>+${x.points} pts</small></div></article>`).join('') : '<div class="empty wide">No captures yet. Complete a quest and your photo will appear here.</div>';
  done.forEach(x=>loadPhotoInto(x.id));
  renderMap(sorted);
  bindQuestCards();
}

function renderMap(list){
  const all=quests, lats=all.map(q=>q.lat), lons=all.map(q=>q.lon), pad=.001;
  const minLat=Math.min(...lats)-pad,maxLat=Math.max(...lats)+pad,minLon=Math.min(...lons)-pad,maxLon=Math.max(...lons)+pad;
  const p=(lat,lon)=>({x:((lon-minLon)/(maxLon-minLon))*100,y:(1-(lat-minLat)/(maxLat-minLat))*100});
  const pts=list.map(q=>{const c=p(q.lat,q.lon);return `<button class="map-pin ${isDone(q.id)?'done':''}" style="left:${c.x}%;top:${c.y}%" data-quest="${q.id}" aria-label="${escapeHtml(q.title)}"><span>${q.points}</span></button>`}).join('');
  let me=''; if(state.currentLocation){const c=p(state.currentLocation.lat,state.currentLocation.lon); if(c.x>=0&&c.x<=100&&c.y>=0&&c.y<=100) me=`<span class="me-pin" style="left:${c.x}%;top:${c.y}%" title="You are here"></span>`;}
  $('#miniMap').innerHTML=`<div class="canal-line l1"></div><div class="canal-line l2"></div><div class="map-label a">CITY CORE</div><div class="map-label b">CANAL QUARTER</div>${pts}${me}<small class="map-note">Schematic quest map · not for navigation</small>`;
  bindQuestCards();
}

function bindQuestCards(){ $$('[data-quest]').forEach(el=>el.onclick=()=>openQuest(el.dataset.quest)); }
function openQuest(id){
  const q=quests.find(x=>x.id===id); if(!q)return; state.activeQuest=q; state.pendingPhoto=null;
  const d=qDistance(q), done=isDone(q.id);
  $('#questDetail').innerHTML=`<span class="eyebrow">${escapeHtml(q.category)} · ${q.points} POINTS</span><div class="detail-icon">${q.icon}</div><h2>${escapeHtml(q.title)}</h2><p class="place">${escapeHtml(q.place)}</p><p class="prompt">${escapeHtml(q.prompt)}</p><div class="hint"><strong>Tip</strong>${escapeHtml(q.hint)}</div>
    ${d!=null?`<div class="proximity ${d<=q.radius?'good':'bad'}">${d<=q.radius?'✓ In range':'⌖ Too far away'} · ${formatDistance(d)} from quest point</div>`:'<div class="proximity">Location is required before completion.</div>'}
    <a class="secondary full link-btn" target="_blank" rel="noopener" href="https://www.google.com/maps/search/?api=1&query=${q.lat},${q.lon}">Open location in Maps</a>
    ${done?'<div class="completed-banner">✓ Quest completed</div>':`<label class="camera-btn primary full"><input id="photoInput" type="file" accept="image/*" capture="environment" hidden>Take / choose photo</label><div id="photoPreview" class="photo-preview" hidden></div><button id="completeBtn" class="primary full" disabled>Complete quest</button><p class="tiny muted">To earn points, you must be within ${q.radius} m of the quest and attach a photo.</p>`}`;
  $('#questDialog').showModal();
  if(!done){ $('#photoInput').onchange=handlePhoto; $('#completeBtn').onclick=completeQuest; }
}

function handlePhoto(e){ const f=e.target.files?.[0]; if(!f)return; if(!f.type.startsWith('image/')){toast('Please choose an image.');return;} state.pendingPhoto=f; const url=URL.createObjectURL(f); const p=$('#photoPreview'); p.innerHTML=`<img src="${url}" alt="Selected quest photograph">`; p.hidden=false; updateCompleteButton(); }
function updateCompleteButton(){ const q=state.activeQuest,d=qDistance(q), btn=$('#completeBtn'); if(!btn)return; btn.disabled=!(state.pendingPhoto && d!=null && d<=q.radius); }

async function completeQuest(){
  const q=state.activeQuest,d=qDistance(q); if(!q||!state.pendingPhoto)return toast('Add a photo first.'); if(d==null)return toast('Enable location first.'); if(d>q.radius)return toast(`Move closer to ${q.place} to complete this quest.`);
  try{
    const blob=await compressImage(state.pendingPhoto); await savePhoto(q.id,blob);
    const p=getProgress(); if(!p.completed.some(x=>x.id===q.id)){p.completed.push({id:q.id,title:q.title,points:q.points,completedAt:new Date().toISOString()}); setProgress(p);}
    $('#questDialog').close(); render(); toast(`+${q.points} points · ${q.title} completed`);
  }catch(err){ console.error(err); toast('Could not save that photo. Try a smaller image.'); }
}

function locate(){
  if(!navigator.geolocation){$('#locationStatus').textContent='Location is not supported by this browser.';return;}
  const btn=$('#locateBtn'); btn.disabled=true; btn.textContent='Locating…';
  navigator.geolocation.getCurrentPosition(pos=>{state.currentLocation={lat:pos.coords.latitude,lon:pos.coords.longitude,accuracy:pos.coords.accuracy}; $('#locationStatus').textContent=`Location ready · accuracy about ${Math.round(pos.coords.accuracy)} m`; btn.disabled=false;btn.textContent='Refresh location';render();updateCompleteButton();},err=>{const msg=err.code===1?'Location permission was denied. Enable it in your browser settings.':'Could not get your location. Try again outdoors or near a window.'; $('#locationStatus').textContent=msg;btn.disabled=false;btn.textContent='Try location again';},{enableHighAccuracy:true,timeout:12000,maximumAge:15000});
}

function nav(name){ $$('.view').forEach(v=>v.classList.remove('active')); $(`#${name}View`).classList.add('active'); $$('.nav-btn').forEach(b=>b.classList.toggle('active',b.dataset.nav===name)); window.scrollTo({top:0,behavior:'smooth'}); if(name==='collection')render(); }
$$('[data-nav]').forEach(b=>b.onclick=()=>nav(b.dataset.nav));
$$('.chip').forEach(b=>b.onclick=()=>{$$('.chip').forEach(x=>x.classList.remove('active'));b.classList.add('active');state.filter=b.dataset.filter;render();});
$('#locateBtn').onclick=locate; $('#closeDialog').onclick=()=>$('#questDialog').close();
$('#questDialog').addEventListener('click',e=>{if(e.target===$('#questDialog'))$('#questDialog').close();});
$('#resetBtn').onclick=async()=>{if(confirm('Reset all BrumQuest points, completed quests and saved photos on this device?')){localStorage.removeItem('brumquest-progress');await clearPhotos();render();toast('Local progress reset.');}};

window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();state.deferredInstall=e;$('#installBtn').hidden=false;});
$('#installBtn').onclick=async()=>{if(!state.deferredInstall)return;state.deferredInstall.prompt();await state.deferredInstall.userChoice;state.deferredInstall=null;$('#installBtn').hidden=true;};
window.addEventListener('appinstalled',()=>{$('#installBtn').hidden=true;toast('BrumQuest installed.');});

function toast(msg){const t=$('#toast');t.textContent=msg;t.classList.add('show');clearTimeout(toast.timer);toast.timer=setTimeout(()=>t.classList.remove('show'),2800);}

function db(){return new Promise((resolve,reject)=>{const req=indexedDB.open('brumquest-db',1);req.onupgradeneeded=()=>req.result.createObjectStore('photos');req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});}
async function savePhoto(id,blob){const d=await db();return new Promise((res,rej)=>{const tx=d.transaction('photos','readwrite');tx.objectStore('photos').put(blob,id);tx.oncomplete=res;tx.onerror=()=>rej(tx.error);});}
async function getPhoto(id){const d=await db();return new Promise((res,rej)=>{const r=d.transaction('photos').objectStore('photos').get(id);r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error);});}
async function clearPhotos(){const d=await db();return new Promise((res,rej)=>{const tx=d.transaction('photos','readwrite');tx.objectStore('photos').clear();tx.oncomplete=res;tx.onerror=()=>rej(tx.error);});}
async function loadPhotoInto(id){const el=document.querySelector(`[data-photo="${id}"]`);if(!el)return;try{const blob=await getPhoto(id);if(blob){const u=URL.createObjectURL(blob);el.innerHTML=`<img src="${u}" alt="Saved challenge photograph">`;}else el.innerHTML='<span>Photo unavailable</span>';}catch{el.innerHTML='<span>Photo unavailable</span>';}}

async function compressImage(file){
  let source, width, height, cleanup=()=>{};
  if('createImageBitmap' in window){
    source=await createImageBitmap(file); width=source.width; height=source.height; cleanup=()=>source.close?.();
  }else{
    const url=URL.createObjectURL(file);
    source=await new Promise((resolve,reject)=>{const img=new Image();img.onload=()=>resolve(img);img.onerror=()=>reject(new Error('Image could not be opened'));img.src=url;});
    width=source.naturalWidth; height=source.naturalHeight; cleanup=()=>URL.revokeObjectURL(url);
  }
  const max=1280, scale=Math.min(1,max/Math.max(width,height)); const w=Math.max(1,Math.round(width*scale)),h=Math.max(1,Math.round(height*scale));
  const canvas=document.createElement('canvas');canvas.width=w;canvas.height=h;canvas.getContext('2d').drawImage(source,0,0,w,h);cleanup();
  return new Promise((res,rej)=>canvas.toBlob(b=>b?res(b):rej(new Error('Image compression failed')),'image/jpeg',0.78));
}

if('serviceWorker' in navigator){window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(console.error));}
render();
